
<?php
/** Lightweight rules storage (JSON in files/_plugins/tagtask/rules.json) */
class PluginTagtaskRulesLib {
   public static function getStorageDir(): string {
      $dir = GLPI_ROOT . '/files/_plugins/tagtask';
      if (!is_dir($dir)) {
         @mkdir($dir, 0775, true);
      }
      return $dir;
   }
   public static function getStorageFile(): string {
      return self::getStorageDir() . '/rules.json';
   }
   public static function getRules(): array {
      $file = self::getStorageFile();
      if (!file_exists($file)) return [];
      $json = @file_get_contents($file);
      if ($json === false) return [];
      $data = json_decode($json, true);
      return is_array($data) ? $data : [];
   }
   public static function saveRules(array $rules): bool {
      $file = self::getStorageFile();
      $json = json_encode(array_values($rules), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
      return @file_put_contents($file, $json) !== false;
   }
}
