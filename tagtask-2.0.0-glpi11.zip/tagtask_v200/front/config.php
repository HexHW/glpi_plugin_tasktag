
<?php
include('../../../inc/includes.php');
require_once __DIR__ . '/../inc/ruleslib.class.php';

Session::checkRight('config', READ);

if (isset($_POST['save']) && Session::haveRight('config', UPDATE)) {
   // Normalise et enregistre
   $rules = [];
   if (!empty($_POST['rules']) && is_array($_POST['rules'])) {
      foreach ($_POST['rules'] as $r) {
         if (empty($r['plugin_tag_tags_id']) || empty($r['content'])) continue;
         $rules[] = [
            'plugin_tag_tags_id' => (int)$r['plugin_tag_tags_id'],
            'content'            => (string)$r['content'],
            'actiontime'         => max(0, (int)$r['actiontime']),
            'is_private'         => isset($r['is_private']) ? 1 : 0,
            'is_active'          => isset($r['is_active']) ? 1 : 0,
         ];
      }
   }
   if (PluginTagtaskRulesLib::saveRules($rules)) {
      Session::addMessageAfterRedirect(__('Règles enregistrées', 'tagtask'), true, INFO);
   } else {
      Session::addMessageAfterRedirect(__('Erreur lors de l'enregistrement des règles', 'tagtask'), true, ERROR);
   }
   Html::back();
}

$rules = PluginTagtaskRulesLib::getRules();

Html::header(__('Tagtask', 'tagtask'), $_SERVER['PHP_SELF'], 'plugins', 'tagtask');

echo '<form method="post" action="' . htmlescape($_SERVER['REQUEST_URI']) . '">';

echo '<table class="tab_cadre_fixe">';
 echo '<tr><th>' . __('Tag (ID)', 'tagtask') . '</th>'
    . '<th>' . __('Contenu de la tâche', 'tagtask') . '</th>'
    . '<th>' . __('Durée (s)', 'tagtask') . '</th>'
    . '<th>' . __('Privée', 'tagtask') . '</th>'
    . '<th>' . __('Active', 'tagtask') . '</th></tr>';

$idx = 0;
foreach ($rules as $r) {
   echo '<tr class="tab_bg_1">';
   echo '<td><input type="number" name="rules['.$idx.'][plugin_tag_tags_id]" value="' . (int)$r['plugin_tag_tags_id'] . '" min="1" style="width:90px"></td>';
   echo '<td><textarea name="rules['.$idx.'][content]" rows="2" cols="60">' . htmlescape($r['content']) . '</textarea></td>';
   echo '<td><input type="number" name="rules['.$idx.'][actiontime]" value="' . (int)($r['actiontime'] ?? 3600) . '" min="0" style="width:110px"></td>';
   echo '<td><input type="checkbox" name="rules['.$idx.'][is_private]" ' . (!empty($r['is_private'])?'checked':'') . '></td>';
   echo '<td><input type="checkbox" name="rules['.$idx.'][is_active]" ' . (!empty($r['is_active'])?'checked':'') . '></td>';
   echo '</tr>';
   $idx++;
}
// ligne vide pour ajout
echo '<tr class="tab_bg_1">';
echo '<td><input type="number" name="rules['.$idx.'][plugin_tag_tags_id]" value="" min="1" style="width:90px"></td>';
echo '<td><textarea name="rules['.$idx.'][content]" rows="2" cols="60"></textarea></td>';
echo '<td><input type="number" name="rules['.$idx.'][actiontime]" value="3600" min="0" style="width:110px"></td>';
echo '<td><input type="checkbox" name="rules['.$idx.'][is_private]" checked></td>';
echo '<td><input type="checkbox" name="rules['.$idx.'][is_active]" checked></td>';
echo '</tr>';

echo '</table>';

echo '<div class="center" style="margin-top:10px">';
Html::submit(_x('button','Save'), ['name' => 'save', 'class' => 'vsubmit']);
echo '</div>';

echo '</form>';

Html::footer();
