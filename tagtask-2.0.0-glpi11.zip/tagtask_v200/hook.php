
<?php
/** hooks for Tagtask (GLPI 11) — no SQL */

defined('GLPI_ROOT') or die('Direct access not allowed');

require_once __DIR__ . '/inc/ruleslib.class.php';

function plugin_tagtask_on_tag_add(CommonDBTM $item) {
   if (!isset($item->fields['itemtype'], $item->fields['items_id'], $item->fields['plugin_tag_tags_id'])) return;
   if ($item->fields['itemtype'] !== 'Ticket') return;
   if (!class_exists('TicketTask')) return;

   $ticket_id = (int)$item->fields['items_id'];
   $tag_id    = (int)$item->fields['plugin_tag_tags_id'];

   $rules = PluginTagtaskRulesLib::getRules();
   if (empty($rules)) return;

   foreach ($rules as $rule) {
      if (empty($rule['is_active'])) continue;
      if ((int)$rule['plugin_tag_tags_id'] !== $tag_id) continue;

      // Anti-doublon simple : même contenu déjà présent ?
      global $DB; $found = $DB->request([
         'SELECT' => ['id'], 'FROM' => TicketTask::getTable(),
         'WHERE'  => ['tickets_id' => $ticket_id, 'content' => $rule['content']],
         'LIMIT'  => 1
      ]);
      if (count($found)) return;

      $seconds = (int)($rule['actiontime'] ?? 3600);
      if ($seconds <= 0) $seconds = 3600;

      $task = new TicketTask();
      $task->add([
         'tickets_id' => $ticket_id,
         'content'    => $rule['content'],
         'is_private' => (int)($rule['is_private'] ?? 1),
         'actiontime' => $seconds
      ]);
      break; // une seule règle par tag
   }
}
