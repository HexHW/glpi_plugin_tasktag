
<?php
/** Tagtask — GLPI 11 (v1.1.1) */

define('PLUGINTAGTASK_VERSION', '1.1.1');

defined('GLPI_ROOT') or die('Direct access not allowed');

function plugin_init_tagtask() {
   global $PLUGIN_HOOKS;
   $PLUGIN_HOOKS['csrf_compliant']['tagtask'] = true;

   // Lien "Configurer" depuis la liste des plugins
   $PLUGIN_HOOKS['config_page']['tagtask'] = 'front/rule.php';

   // Hook sur l'ajout de la liaison Tag → Item
   $PLUGIN_HOOKS['item_add']['tagtask'] = [
      'PluginTagTagItem' => 'plugin_tagtask_on_tag_add'
   ];
}

function plugin_version_tagtask() {
   return [
      'name'           => __('Tagtask', 'tagtask'),
      'version'        => PLUGINTAGTASK_VERSION,
      'author'         => 'Brice Sautrel / Copilot',
      'license'        => 'GPLv2+',
      'homepage'       => 'https://mediaschool.example/tagtask',
      'minGlpiVersion' => '11.0.0',
      'maxGlpiVersion' => '11.0.99'
   ];
}

function plugin_tagtask_check_prerequisites() {
   if (PHP_VERSION_ID < 80300) {
      echo __('PHP 8.3 minimum requis', 'tagtask');
      return false;
   }
   return true;
}

function plugin_tagtask_check_config($verbose = false) { return true; }

function plugin_tagtask_install() { return PluginTagtaskInstall::install(); }
function plugin_tagtask_uninstall() { return PluginTagtaskInstall::uninstall(); }
