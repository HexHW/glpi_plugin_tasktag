
<?php

defined('GLPI_ROOT') or die('Direct access not allowed');

class PluginTagtaskInstall {
   public static function install(): bool {
      global $DB;
      $migration = new Migration(PLUGINTAGTASK_VERSION);
      $table = 'glpi_plugin_tagtask_rules';
      if (!$DB->tableExists($table)) {
         $query = "CREATE TABLE `$table` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `plugin_tag_tags_id` INT UNSIGNED NOT NULL,
            `content` TEXT NOT NULL,
            `actiontime` INT UNSIGNED NOT NULL DEFAULT 3600,
            `is_private` TINYINT(1) NOT NULL DEFAULT 1,
            `is_active` TINYINT(1) NOT NULL DEFAULT 1,
            `date_mod` DATETIME NULL,
            PRIMARY KEY (`id`),
            KEY `plugin_tag_tags_id` (`plugin_tag_tags_id`),
            KEY `is_active` (`is_active`)
         ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
         $DB->queryOrDie($query, $DB->error());
      }
      $migration->executeMigration();
      return true;
   }
   public static function uninstall(): bool { return true; }
}
