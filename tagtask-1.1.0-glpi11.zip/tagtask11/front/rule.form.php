
<?php
include('../../../inc/includes.php');

$rule = new PluginTagtaskRule();

if (isset($_POST['add'])) {
   $rule->check(-1, CREATE, $_POST);
   $rule->add($_POST);
   Html::redirect(Toolbox::getItemTypeSearchURL('PluginTagtaskRule'));
}

if (isset($_POST['update'])) {
   $rule->check($_POST['id'], UPDATE);
   $rule->update($_POST);
   Html::redirect(Toolbox::getItemTypeSearchURL('PluginTagtaskRule'));
}

$rule->showForm(isset($_GET['id']) ? (int)$_GET['id'] : -1);
