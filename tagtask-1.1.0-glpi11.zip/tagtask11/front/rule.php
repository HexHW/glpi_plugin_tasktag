
<?php
include('../../../inc/includes.php');
Session::checkRight('config', READ);

$rule = new PluginTagtaskRule();

Html::header(__('Tagtask', 'tagtask'), $_SERVER['PHP_SELF'], 'plugins', 'PluginTagtaskRule');

if ($rule->canCreate()) {
   echo '<div class="center"><a class="vsubmit" href="rule.form.php">' . __('Ajouter une règle', 'tagtask') . '</a></div><br>';
}

Search::show('PluginTagtaskRule');
Html::footer();
