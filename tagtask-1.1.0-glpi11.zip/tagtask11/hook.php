
<?php
/** hooks for Tagtask (GLPI 11) */

defined('GLPI_ROOT') or die('Direct access not allowed');

/**
 * Appelé quand un tag est ajouté à un item (PluginTagTagItem)
 * @param CommonDBTM $item instance de PluginTagTagItem
 */
function plugin_tagtask_on_tag_add(CommonDBTM $item) {
   global $DB;

   if (!isset($item->fields['itemtype'], $item->fields['items_id'], $item->fields['plugin_tag_tags_id'])) {
      return;
   }
   if ($item->fields['itemtype'] !== 'Ticket') {
      return; // on ne traite que les tickets
   }

   $ticket_id = (int)$item->fields['items_id'];
   $tag_id    = (int)$item->fields['plugin_tag_tags_id'];

   $rule = new PluginTagtaskRule();
   if (!$rule->getFromDBByCrit(['plugin_tag_tags_id' => $tag_id, 'is_active' => 1])) {
      return;
   }

   // Anti-doublon: tâche avec même contenu déjà existante ?
   $iterator = $DB->request([
      'SELECT' => ['id'],
      'FROM'   => TicketTask::getTable(),
      'WHERE'  => [
         'tickets_id' => $ticket_id,
         'content'    => $rule->fields['content']
      ],
      'LIMIT'  => 1
   ]);
   if (count($iterator)) return;

   $seconds = (int)$rule->fields['actiontime'];
   if ($seconds <= 0) $seconds = 3600;

   $task = new TicketTask();
   $task->add([
      'tickets_id' => $ticket_id,
      'content'    => $rule->fields['content'],
      'is_private' => (int)$rule->fields['is_private'],
      'actiontime' => $seconds
   ]);
}
