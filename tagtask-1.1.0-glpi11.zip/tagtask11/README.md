
# Tagtask (GLPI 11)

Crée automatiquement des **tâches** sur les **tickets** quand un **Tag** (plugin [Tag](https://github.com/pluginsGLPI/tag)) est ajouté.

- Associez un **Tag** à une **règle** (contenu, durée, privé/public)
- À chaque ajout dudit Tag sur un ticket, une **tâche** est créée automatiquement

## Compatibilité
- GLPI: 11.0.x
- PHP: ≥ 8.3

## Installation
1. Copier `tagtask/` dans `.../glpi/plugins/`
2. **Configuration > Plugins** → *Installer* puis *Activer* `Tagtask`
3. **Plugins > Tagtask** pour gérer les règles
