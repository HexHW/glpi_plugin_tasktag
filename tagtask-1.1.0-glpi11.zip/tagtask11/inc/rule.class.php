
<?php

defined('GLPI_ROOT') or die('Direct access not allowed');

class PluginTagtaskRule extends CommonDBTM {
   public static $rightname = ''; // on s'appuie sur le droit core 'config'

   public static function getTypeName($nb = 0) {
      return _n('Règle Tagtask', 'Règles Tagtask', $nb, 'tagtask');
   }

   public static function getTable($classname = null) { return 'glpi_plugin_tagtask_rules'; }

   public function canView()   { return Session::haveRight('config', READ); }
   public function canCreate() { return Session::haveRight('config', UPDATE); }
   public function canUpdate() { return Session::haveRight('config', UPDATE); }
   public function canDelete() { return Session::haveRight('config', UPDATE); }

   public function showForm($ID, array $options = []) {
      if (!$this->canView()) return false;
      $this->initForm($ID, $options);
      $this->showFormHeader($options);

      echo '<tr class="tab_bg_1">';
      echo '<td>' . __('Tag', 'tagtask') . '</td><td>';
      Dropdown::show('PluginTagTag', [
         'name'  => 'plugin_tag_tags_id',
         'value' => $this->fields['plugin_tag_tags_id'] ?? 0
      ]);
      echo '</td>';
      echo '<td>' . __('Active', 'tagtask') . '</td><td>';
      Dropdown::showYesNo('is_active', $this->fields['is_active'] ?? 1);
      echo '</td>';
      echo '</tr>';

      echo '<tr class="tab_bg_1">';
      echo '<td>' . __('Contenu de la tâche', 'tagtask') . '</td><td colspan="3">';
      echo Html::textarea(['name' => 'content', 'value' => $this->fields['content'] ?? '', 'rows' => 4, 'cols' => 80]);
      echo '</td>';
      echo '</tr>';

      echo '<tr class="tab_bg_1">';
      echo '<td>' . __('Durée (minutes)', 'tagtask') . '</td><td>';
      $minutes = isset($this->fields['actiontime']) ? (int)($this->fields['actiontime']/60) : 60;
      echo Html::input('duration_minutes', ['value' => $minutes, 'size' => 6]);
      echo '</td>';
      echo '<td>' . __('Tâche privée', 'tagtask') . '</td><td>';
      Dropdown::showYesNo('is_private', $this->fields['is_private'] ?? 1);
      echo '</td>';
      echo '</tr>';

      $this->showFormButtons($options);
      return true;
   }

   public function prepareInputForAdd($input) {
      if (isset($input['duration_minutes'])) {
         $input['actiontime'] = max(0, (int)$input['duration_minutes']) * 60;
         unset($input['duration_minutes']);
      }
      $input['date_mod'] = date('Y-m-d H:i:s');
      return $input;
   }

   public function prepareInputForUpdate($input) {
      if (isset($input['duration_minutes'])) {
         $input['actiontime'] = max(0, (int)$input['duration_minutes']) * 60;
         unset($input['duration_minutes']);
      }
      $input['date_mod'] = date('Y-m-d H:i:s');
      return $input;
   }

   public static function getSearchOptionsToAdd() {
      $sopt = [];
      $sopt[1]['table'] = self::getTable();
      $sopt[1]['field'] = 'id';
      $sopt[1]['name']  = __('ID');

      $sopt[2]['table'] = self::getTable();
      $sopt[2]['field'] = 'plugin_tag_tags_id';
      $sopt[2]['name']  = __('Tag', 'tagtask');

      $sopt[3]['table'] = self::getTable();
      $sopt[3]['field'] = 'content';
      $sopt[3]['name']  = __('Contenu', 'tagtask');

      $sopt[4]['table'] = self::getTable();
      $sopt[4]['field'] = 'actiontime';
      $sopt[4]['name']  = __('Durée (s)', 'tagtask');

      $sopt[5]['table'] = self::getTable();
      $sopt[5]['field'] = 'is_private';
      $sopt[5]['name']  = __('Privée', 'tagtask');

      $sopt[6]['table'] = self::getTable();
      $sopt[6]['field'] = 'is_active';
      $sopt[6]['name']  = __('Active', 'tagtask');

      return $sopt;
   }
}
