
<?php

defined('GLPI_ROOT') or die('Direct access not allowed');

class PluginTagtaskInstall {
   public static function install(): bool {
      global $DB;
      $table = 'glpi_plugin_tagtask_rules';
      if (!$DB->tableExists($table)) {
         // Pas de requête SQL directe (GLPI 11 bloque les requêtes brutes) : on demande une création manuelle
         $sql = "CREATE TABLE `glpi_plugin_tagtask_rules` (
"
              . " `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
"
              . " `plugin_tag_tags_id` INT UNSIGNED NOT NULL,
"
              . " `content` TEXT NOT NULL,
"
              . " `actiontime` INT UNSIGNED NOT NULL DEFAULT 3600,
"
              . " `is_private` TINYINT(1) NOT NULL DEFAULT 1,
"
              . " `is_active` TINYINT(1) NOT NULL DEFAULT 1,
"
              . " `date_mod` DATETIME NULL,
"
              . " PRIMARY KEY (`id`), KEY `plugin_tag_tags_id` (`plugin_tag_tags_id`), KEY `is_active` (`is_active`)
"
              . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
         Session::addMessageAfterRedirect(
            sprintf(__('Tagtask : la table "%s" est absente. Exécutez la création SQL suivante en CLI puis relancez l'installation : %s', 'tagtask'), $table, htmlescape($sql)),
            true,
            INFO
         );
      }
      return true;
   }

   public static function uninstall(): bool { return true; }
}
