
<?php
include('../../../inc/includes.php');
Session::checkRight('config', READ);

$rule = new PluginTagtaskRule();
Html::header(__('Tagtask', 'tagtask'), $_SERVER['PHP_SELF'], 'plugins', 'PluginTagtaskRule');
if ($rule->canCreate()) {
   echo '<div class="center"><a class="vsubmit" href="rule.form.php">' . __('Ajouter une règle', 'tagtask') . '</a></div><br>';
}
if (!DB::getDB()->tableExists(PluginTagtaskRule::getTable())) {
   echo Html::warning(__('La table de règles est absente. Terminez l'installation depuis Configuration > Plugins.', 'tagtask'));
} else {
   Search::show('PluginTagtaskRule');
}
Html::footer();
