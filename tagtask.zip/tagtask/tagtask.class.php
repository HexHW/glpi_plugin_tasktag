<?php

class PluginTagTask {

    public static function checkTagAndCreateTask($ticket) {
        global $DB;

        $ticket_id = $ticket->fields['id'];

        // Vérifie les tags du ticket
        $query = "SELECT tag FROM glpi_plugin_tags_tickets WHERE tickets_id = $ticket_id";
        $result = $DB->query($query);

        while ($row = $DB->fetch_assoc($result)) {
            if ($row['tag'] === 'PC-Renouvellement') {
                // Crée une tâche
                $task = new TicketTask();
                $task->add([
                    'tickets_id' => $ticket_id,
                    'content'    => 'Préparation d'un PC',
                    'duration'   => 3600,
                    'users_id'   => Session::getLoginUserID(),
                    'taskcategories_id' => 0
                ]);
            }
        }
    }
}