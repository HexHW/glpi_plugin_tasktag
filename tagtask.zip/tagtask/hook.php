<?php

function plugin_tagtask_ticket_update($ticket) {
    PluginTagTask::checkTagAndCreateTask($ticket);
}