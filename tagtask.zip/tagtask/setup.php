<?php

function plugin_init_tagtask() {
    global $PLUGIN_HOOKS;

    $PLUGIN_HOOKS['ticket_update']['tagtask'] = ['PluginTagTask::checkTagAndCreateTask'];
}

function plugin_version_tagtask() {
    return [
        'name'           => 'TagTask',
        'version'        => '1.0.0',
        'author'         => 'Brice Sautrel',
        'license'        => 'GPLv2+',
        'homepage'       => 'https://ton-site-ou-github.com',
        'minGlpiVersion' => '11.0.0'
    ];
}

function plugin_tagtask_check_config($verbose = false) {
    return true;
}