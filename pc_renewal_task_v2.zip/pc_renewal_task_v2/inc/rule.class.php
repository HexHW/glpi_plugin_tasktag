<?php
class PluginPcRenewalTaskRule extends CommonDBTM {

   static $rightname = 'plugin_pc_renewal_task_rule';

   static function getTypeName($nb = 0) {
      return _n('Règle automatique', 'Règles automatiques', $nb, 'pc_renewal_task');
   }

   function getSearchOptionsNew() {
      $tab = [];
      $tab[] = ['id' => '1', 'name' => __('Tag', 'pc_renewal_task')];
      $tab[] = ['id' => '2', 'name' => __('Contenu de la tâche', 'pc_renewal_task')];
      $tab[] = ['id' => '3', 'name' => __('Durée (secondes)', 'pc_renewal_task')];
      return $tab;
   }
}
?>
