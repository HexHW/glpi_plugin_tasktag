<?php
class PluginPcRenewalTaskAutoTask {

   static function checkTicket(Ticket $ticket) {
      global $DB;

      $ticket_id = $ticket->getID();
      $rules = $DB->request("SELECT * FROM glpi_plugin_pc_renewal_task_rules");

      foreach ($rules as $rule) {
         if (self::ticketHasTag($ticket_id, $rule['tag_name'])) {
            self::createTask($ticket_id, $rule['task_content'], $rule['task_duration']);
         }
      }
   }

   static function ticketHasTag($ticket_id, $tagName) {
      global $DB;
      $tag_table = 'glpi_plugin_tag_tags_items';
      if (!$DB->tableExists($tag_table)) return false;
      $query = "SELECT COUNT(*) as c FROM $tag_table ti
                JOIN glpi_plugin_tag_tags t ON t.id = ti.plugin_tag_tags_id
                WHERE ti.items_id = $ticket_id AND ti.itemtype = 'Ticket' AND t.name = '" . addslashes($tagName) . "'";
      $res = $DB->query($query);
      $data = $DB->fetchAssoc($res);
      return ($data['c'] > 0);
   }

   static function createTask($ticket_id, $content, $duration) {
      $task = new TicketTask();
      $task->add([
         'tickets_id' => $ticket_id,
         'content'    => $content,
         'actiontime' => $duration,
         'users_id'   => 0,
      ]);
   }
}
?>
