<?php
class PluginPcRenewalTaskMenu extends CommonGLPI {

   static function getMenuName() {
      return __('PC Renewal Task', 'pc_renewal_task');
   }

   static function getMenuContent() {
      return [
         'title' => self::getMenuName(),
         'page'  => '/plugins/pc_renewal_task/front/rule.form.php',
         'icon'  => 'fa-tasks'
      ];
   }
}
?>
