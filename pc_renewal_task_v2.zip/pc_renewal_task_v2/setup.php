<?php
function plugin_init_pc_renewal_task() {
   global $PLUGIN_HOOKS;

   $PLUGIN_HOOKS['csrf_compliant']['pc_renewal_task'] = true;
   $PLUGIN_HOOKS['menu_entry']['pc_renewal_task'] = true;
   $PLUGIN_HOOKS['config_page']['pc_renewal_task'] = 'front/rule.form.php';
   $PLUGIN_HOOKS['post_item_add']['pc_renewal_task'] = ['Ticket' => ['PluginPcRenewalTaskAutoTask', 'checkTicket']];
   $PLUGIN_HOOKS['post_item_update']['pc_renewal_task'] = ['Ticket' => ['PluginPcRenewalTaskAutoTask', 'checkTicket']];
}

function plugin_version_pc_renewal_task() {
   return [
      'name'           => 'PC Renewal Task',
      'version'        => '2.0.0',
      'author'         => 'Brice S',
      'license'        => 'GPLv2+',
      'homepage'       => 'https://github.com/',
      'minGlpiVersion' => '11.0'
   ];
}

function plugin_pc_renewal_task_install() {
   global $DB;
   $query = "CREATE TABLE IF NOT EXISTS `glpi_plugin_pc_renewal_task_rules` (
      `id` INT AUTO_INCREMENT PRIMARY KEY,
      `tag_name` VARCHAR(255) NOT NULL,
      `task_content` TEXT NOT NULL,
      `task_duration` INT DEFAULT 3600
   ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
   $DB->query($query);
   return true;
}

function plugin_pc_renewal_task_uninstall() {
   global $DB;
   $DB->query("DROP TABLE IF EXISTS `glpi_plugin_pc_renewal_task_rules`;");
   return true;
}
?>
