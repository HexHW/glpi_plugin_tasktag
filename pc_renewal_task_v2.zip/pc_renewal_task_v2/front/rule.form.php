<?php
include ('../../../inc/includes.php');

Session::checkRight('config', READ);

$rule = new PluginPcRenewalTaskRule();

if (isset($_POST['add'])) {
   $rule->add($_POST);
   Html::back();
} else if (isset($_POST['update'])) {
   $rule->update($_POST);
   Html::back();
} else if (isset($_POST['delete'])) {
   $rule->delete($_POST);
   Html::back();
}

Html::header(__('Règles automatiques', 'pc_renewal_task'), $_SERVER['PHP_SELF'], 'config', 'pluginpcrenewaltaskmenu');

Search::show('PluginPcRenewalTaskRule');

if (Session::haveRight('config', UPDATE)) {
   $rule->showForm(-1);
}

Html::footer();
?>
