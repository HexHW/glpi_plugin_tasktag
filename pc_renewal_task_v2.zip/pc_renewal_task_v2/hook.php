<?php
function plugin_item_update_pc_renewal_task($item) {
   if ($item->getType() == 'Ticket') {
      PluginPcRenewalTaskAutoTask::checkTicket($item);
   }
}
?>
