
<?php

defined('GLPI_ROOT') or die('Direct access not allowed');

class PluginTagtaskInstall {
   public static function install(): bool {
      global $DB;
      $migration = new Migration(PLUGINTAGTASK_VERSION);
      $table = 'glpi_plugin_tagtask_rules';

      if (!$DB->tableExists($table)) {
         // Déclaration du schéma via l’API Migration (GLPI 11 bloque les requêtes SQL brutes)
         $migration->addTable($table, [
            'id'                 => 'autoincrement',
            'plugin_tag_tags_id' => 'integer',
            'content'            => 'text',
            'actiontime'         => 'integer',    // secondes
            'is_private'         => 'bool',
            'is_active'          => 'bool',
            'date_mod'           => 'datetime',
         ]);
         $migration->addKey($table, 'plugin_tag_tags_id');
         $migration->addKey($table, 'is_active');
      }

      $migration->executeMigration();
      return true;
   }

   public static function uninstall(): bool { return true; }
}
